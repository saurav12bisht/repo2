const mongoose = require('mongoose');

const whatsappdata = new mongoose.Schema({
    groupname: {
        type: String,
        required: true,
    },
    grouplink: {
        type: String,
        required: true,
    },
    groupdesc: {
        type: String,
        required:true
    },
    userid:{
        type:String
        
    }
    


    
});

module.exports = mongoose.model('whatsappdata', whatsappdata);