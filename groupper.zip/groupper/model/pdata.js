const mongoose = require('mongoose');

const pdata = new mongoose.Schema({
    g_name: {
        type: String,
    },
    g_discription: {
        type: String,
    },
    veh1: {
        type: String,
    },
    veh2: {
        type: String,
    },
    veh3: {
        type: String,
    }
});

module.exports = mongoose.model('pdata', pdata);