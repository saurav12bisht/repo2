module.exports.clientId = "<Add Your Client ID>";
module.exports.clientSecret = "<Add Your Client Secret>";